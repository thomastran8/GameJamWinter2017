Werewolves and Cheese Wheels and Vampires

Description:
    The war, if one can call it that, was a long, arduous affair. For all of the might of the Whey Empire, their newly found natural predators simply had the upper hand on them. Including the lack of manipulating digits, the citizens of the Empire also were inferior in terms of technology and resources compared to Lycans.

And so, the behemoth of an Empire that had reigned for the good half of a thousand years was slowly but surely ground to curds, their mighty towers felled and the rubble seized as a delicacy food to feed highborn Lycans.

But even as the light and Lactobacillus was snuffed out, there still remained a few dairy products who would not give up the good fight. A few who still remembered what it had been like to be free—and not simply a delicious and nutritious food source. A few who still waged their personal wars, even in this dying era of a devoured nation.

This is the story of a cheese wheel and its quest for vengeance.


Controls: 
    A/D to move left or right
    Space to jump
    W to attack

Team Members:
    Thomas Tran
    Joshua Zhang
    Davey Jay Belliss


All art by Joshua Zhang

All sound and music by Kristin Kirk
